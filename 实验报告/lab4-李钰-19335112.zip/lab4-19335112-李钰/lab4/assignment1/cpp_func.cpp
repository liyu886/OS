#include <iostream>
using namespace std;

extern "C" void function_from_CPP() {
    cout << "This is a function from C++." << endl;
}