#include "asm_utils.h"

extern "C" void setup_kernel()
{
    asm_number();
    while(1) {

    }
}
