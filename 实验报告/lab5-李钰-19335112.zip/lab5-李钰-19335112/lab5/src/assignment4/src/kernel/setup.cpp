#include "asm_utils.h"
#include "interrupt.h"
#include "stdio.h"
#include "program.h"
#include "thread.h"
#define thread_count 10

// 屏幕IO处理器
STDIO stdio;
// 中断管理器
InterruptManager interruptManager;
// 程序管理器
ProgramManager programManager;

void thread_fun(void *arg){
    
    printf("I'm %s, and my pid is %d, and my priority is %d, nice to meet you.\n", programManager.running->name, programManager.running->pid, programManager.running->priority);
    if(programManager.running->pid == 0){
        printf("schedule other thread.\n");
        programManager.schedule();
        printf("%s resume.\n", programManager.running->name);
    }
    
}

extern "C" void setup_kernel()
{

    // 中断管理器
    interruptManager.initialize();
    interruptManager.enableTimeInterrupt();
    interruptManager.setTimeInterrupt((void *)asm_time_interrupt_handler);

    // 输出管理器
    stdio.initialize();

    // 进程/线程管理器
    programManager.initialize();

    //create 4 threads, and add their PCB to PCB_SET
    for(int i = 0; i < thread_count; i++){
        char name[10] = "thread ";
        char c = 'A' + i;
        name[7] = c;
        name[8] = '\0';

        int priority = 37 * (i + 1) % 5; //2, 4, 1, 3
        if(priority == 0){
            priority++;
        }

        int pid = programManager.executeThread(thread_fun, nullptr, name, priority);
        if (pid == -1)
        {
            printf("can not execute thread\n");
            asm_halt();
        }else{
            printf("The %d thread has been created, its name is %s.\n", i, name);
        }
    }

 

    ListItem *item = programManager.readyPrograms.front();
    PCB *firstThread = ListItem2PCB(item, tagInGeneralList);
    int min_priority = firstThread->priority;
    int k = 0;

    for(int j = 1; j < programManager.readyPrograms.size(); j++){
        ListItem* move = item->next;
        PCB* temp = ListItem2PCB(move, tagInGeneralList);
        if(temp->priority < min_priority){
            min_priority = temp->priority;
            k = j;
        }
        item = move;
    }

    if(k == 0){
        item = programManager.readyPrograms.at(k);
        firstThread = ListItem2PCB(item, tagInGeneralList);
        firstThread->status = RUNNING;
        programManager.readyPrograms.erase(item);
        programManager.running = firstThread;  
        asm_switch_thread(0, firstThread);
    }else{
        programManager.schedule();
    }
    
    asm_halt();
}
