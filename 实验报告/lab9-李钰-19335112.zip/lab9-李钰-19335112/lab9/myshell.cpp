#include<iostream>
#include<string>
#include<unistd.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<cstdio>
#include<cstring>
#include<cstdlib>

using namespace std;

#define NUM 32
#define SIZE 256

//解析指令
void CommandParse(char* cmd,char** argv)
{
	
	int i = 0;
	argv[i++] = strtok(cmd," ");
	while(1)
	{
		argv[i] = strtok(NULL," ");
		if(argv[i] == NULL)
			break;
		i++;
	}
}
//执行指令（进程替换）
void ExecCommand(char** argv)
{
	
	pid_t id = fork();
	if(id == 0)
	{
		execvp(argv[0],argv);
		exit(13);
	}
	else
	{
		int st = 0;
		waitpid(id,&st,0);
	}
}
int main()
{
	const string tip = "LiYuyu@ ";
	char* argv[NUM] = {NULL};
	while(1)
	{
		char cmd[SIZE];
		cout<<tip;	//shell信息
		fgets(cmd,sizeof(cmd)-1,stdin);
		cmd[strlen(cmd)-1] = 0;
		CommandParse(cmd,argv);
		ExecCommand(argv);	
	}
	return 0;
}
